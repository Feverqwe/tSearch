$(function(){$('form[name="search"]').submit(function(a){a.preventDefault();chrome.tabs.create({url:"index.html#s="+$(this).children('input[type="text"]').val()})})});
