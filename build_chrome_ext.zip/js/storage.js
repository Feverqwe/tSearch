var SetSettings=function(a,b){return localStorage[a]=b},GetSettings=function(a){return void 0===localStorage[a]?void 0:localStorage[a]};
